# MaxLedger by Sanjay S

Personal cash and finance tracker. Web app in `www/index.html`, wrapped for Android with Capacitor.

## Put it on GitHub
1. Create a new empty repository on github.com (private is fine for the APK; Pages on a private repo needs a paid plan).
2. Upload everything in this folder, keeping the `.github/workflows` folder, or run:
   git init && git add . && git commit -m "MaxLedger" && git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git && git push -u origin main

## Get the Android APK
1. Open the repo's **Actions** tab and wait for **Build debug APK** to finish (about 5 to 10 minutes). You can also start it with **Run workflow**.
2. Open the finished run, download the **maxledger-debug-apk** artifact, and unzip it.
3. Copy `app-debug.apk` to your phone and open it. Allow "Install unknown apps" for your file manager or browser when asked.

## Get the website
Repo **Settings > Pages > Source: GitHub Actions**. After the next push, the **Deploy web app** workflow publishes it at https://YOUR-USERNAME.github.io/YOUR-REPO/

## Notes
- Data is stored on the device (localStorage). Use Settings > Export JSON to back it up.
- This is a debug build for testing. A signed release APK needs a keystore stored as GitHub Secrets.
- Not yet implemented: cloud sync, calendar and reminders, biometrics, PDF and Excel export.
